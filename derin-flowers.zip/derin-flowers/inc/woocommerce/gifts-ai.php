<?php
/**
 * Ürün sayfasında hediye ekleme (ayıcık, pasta, çikolata… gerçek WooCommerce ürünleri)
 * ve kart notu için yapay zekâ önerisi.
 *
 * @package DerinFlowers
 */

defined( 'ABSPATH' ) || exit;

/* -------------------------------------------------------------------------
 * Hediyeler
 * ---------------------------------------------------------------------- */

/**
 * Hediye ürünleri (satın alınabilir, stokta, basit ürünler).
 *
 * @param int $exclude Hariç tutulacak ürün.
 * @return WC_Product[]
 */
function df_gift_products( $exclude = 0 ) {
	if ( ! df_opt( 'gift_on', 1 ) ) {
		return array();
	}
	$ids = array_filter( array_map( 'absint', (array) df_opt( 'gift_products', array() ) ) );
	$cat = absint( df_opt( 'gift_cat' ) );
	if ( ! $ids && ! $cat ) {
		$cat = df_gift_auto_cat();
	}
	if ( ! $ids && $cat ) {
		$term = get_term( $cat, 'product_cat' );
		if ( $term && ! is_wp_error( $term ) ) {
			$ids = wc_get_products(
				array(
					'status'   => 'publish',
					'limit'    => 12,
					'category' => array( $term->slug ),
					'return'   => 'ids',
					'orderby'  => 'menu_order',
					'order'    => 'ASC',
				)
			);
		}
	}
	// Hiç hediye kategorisi yoksa adından hediye olduğu anlaşılan ürünler (ayıcık, peluş, balon…).
	if ( ! $ids && ! $cat ) {
		$ids = df_gift_auto_products();
	}
	$out = array();
	foreach ( $ids as $id ) {
		$p = wc_get_product( $id );
		if ( $p && (int) $id !== (int) $exclude && $p->is_type( 'simple' ) && $p->is_purchasable() && $p->is_in_stock() ) {
			$out[] = $p;
		}
	}
	// Elle sıralanmadıysa en çok satan hediyeler önce.
	if ( ! df_opt( 'gift_products' ) ) {
		usort(
			$out,
			function ( $a, $b ) {
				return (int) $b->get_total_sales() - (int) $a->get_total_sales();
			}
		);
	}
	return $out;
}

/**
 * Hediye kelimeleri.
 *
 * @return string
 */
function df_gift_pattern() {
	return '/(hediye|ay[ıi]c[ıi]k|pel[uü][sş]|teddy|[cç]ikolata|pasta|kek|balon|makaron|kurabiye|mum|vazo hediye|gift)/iu';
}

/**
 * Adında "hediye" geçen ürün kategorisi.
 *
 * @return int
 */
function df_gift_auto_cat() {
	$terms = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
		)
	);
	if ( is_wp_error( $terms ) ) {
		return 0;
	}
	// Önce birebir "Hediyeler / Hediye / Hediye Ürünleri", sonra adı "hediye" ile başlayan.
	$best  = 0;
	$score = 0;
	foreach ( $terms as $t ) {
		$name = mb_strtolower( trim( $t->name ) );
		$slug = strtolower( $t->slug );
		$sc   = 0;
		if ( in_array( $name, array( 'hediyeler', 'hediye', 'hediye ürünleri', 'hediyelikler' ), true ) || in_array( $slug, array( 'hediyeler', 'hediye', 'hediye-urunleri', 'gifts', 'gift' ), true ) ) {
			$sc = 3;
		} elseif ( 0 === strpos( $slug, 'hediye' ) ) {
			$sc = 1;
		}
		if ( $sc > $score ) {
			$score = $sc;
			$best  = (int) $t->term_id;
		}
	}
	return $best;
}

/**
 * Adından hediye olduğu anlaşılan ürünler.
 *
 * @return int[]
 */
function df_gift_auto_products() {
	$cached = get_transient( 'df_gift_auto' );
	if ( is_array( $cached ) ) {
		return $cached;
	}
	$ids = array();
	foreach ( wc_get_products( array( 'status' => 'publish', 'limit' => 300, 'type' => 'simple', 'return' => 'objects' ) ) as $p ) {
		if ( preg_match( df_gift_pattern(), $p->get_name() ) && $p->get_price() !== '' && (float) $p->get_price() < (float) df_opt( 'gift_max_price', 1500 ) ) {
			$ids[] = $p->get_id();
		}
		if ( count( $ids ) >= 12 ) {
			break;
		}
	}
	set_transient( 'df_gift_auto', $ids, HOUR_IN_SECONDS );
	return $ids;
}
add_action(
	'save_post_product',
	function () {
		delete_transient( 'df_gift_auto' );
	}
);

/**
 * Hediye kategorisindeki ürünler vitrin / benzer ürün / ana sayfa listelerinde çıkmasın.
 *
 * @return int[]
 */
function df_gift_ids_all() {
	static $ids = null;
	if ( null === $ids && ! df_opt( 'gift_products' ) && ! df_opt( 'gift_cat' ) && ! df_gift_auto_cat() ) {
		$ids = array(); // Ada göre bulunan hediyeler listelerden gizlenmez.
	}
	if ( null === $ids ) {
		$ids = array_map(
			function ( $p ) {
				return $p->get_id();
			},
			df_gift_products()
		);
	}
	return $ids;
}

/**
 * Ürün sayfasında hediye adımı (hızlı sipariş alanlarının en başında).
 */
function df_gift_step() {
	global $product;
	if ( ! $product || ! function_exists( 'df_quick_order_on' ) ) {
		return;
	}
	$gifts = df_gift_products( $product->get_id() );
	if ( in_array( $product->get_id(), df_gift_ids_all(), true ) || ! df_opt( 'gift_on', 1 ) ) {
		return;
	}
	if ( ! $gifts ) {
		if ( current_user_can( 'manage_woocommerce' ) ) {
			echo '<p class="df-gift-admin">' . df_icon( 'info', array( 'size' => 16 ) ) . '<span><strong>Yönetici notu:</strong> Hediye önerisi gösterilecek ürün bulunamadı. WooCommerce\'te "Hediyeler" kategorisi açıp ayıcık, çikolata, pasta gibi ürünleri ekleyin (ya da Ürün & Mağaza → Ürün detay sayfası\'ndan seçin). Bu not yalnızca size görünür.</span></p>'; // phpcs:ignore
		}
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Missing
	$picked = isset( $_POST['df_gifts'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['df_gifts'] ) ) : array();
	?>
	<section class="df-step df-gifts" id="df-step-gifts">
		<h2 class="df-step__title"><span class="df-step__num">5</span><?php echo esc_html( df_opt( 'gift_title', 'Hediye Ekle' ) ); ?> <small class="df-gifts__opt">(isteğe bağlı)</small></h2>
		<p class="df-step__desc">Çiçeğinizin yanına eklemek istediğiniz hediyeyi seçin; aynı paketle teslim edilir.</p>
		<div class="df-gifts__grid">
			<?php foreach ( $gifts as $gi => $g ) : ?>
				<label class="df-gift">
					<input type="checkbox" name="df_gifts[]" value="<?php echo (int) $g->get_id(); ?>" data-price="<?php echo esc_attr( wc_get_price_to_display( $g ) ); ?>" data-name="<?php echo esc_attr( $g->get_name() ); ?>" <?php checked( in_array( $g->get_id(), $picked, true ) ); ?>>
					<span class="df-gift__box">
						<?php if ( $gi < 2 ) : ?>
							<span class="df-gift__badge"><?php echo 0 === $gi ? 'Çok tercih edilen' : 'Önerilen'; ?></span>
						<?php endif; ?>
						<span class="df-gift__img"><?php echo $g->get_image_id() ? wp_get_attachment_image( $g->get_image_id(), 'thumbnail', false, array( 'alt' => '' ) ) : df_placeholder(); // phpcs:ignore ?></span>
						<span class="df-gift__name"><?php echo esc_html( $g->get_name() ); ?></span>
						<span class="df-gift__price">+<?php echo wp_kses_post( wc_price( wc_get_price_to_display( $g ) ) ); ?></span>
						<span class="df-gift__check" aria-hidden="true"><?php df_the_icon( 'check', array( 'size' => 14 ) ); ?></span>
					</span>
				</label>
			<?php endforeach; ?>
		</div>
	</section>
	<?php
}

/**
 * Ana ürün sepete eklenince seçilen hediyeleri de ekle.
 *
 * @param string $key        Sepet anahtarı.
 * @param int    $product_id Ürün.
 */
function df_gift_add_to_cart( $key, $product_id ) {
	static $busy = false;
	// phpcs:ignore WordPress.Security.NonceVerification.Missing
	if ( $busy || empty( $_POST['df_gifts'] ) || ! WC()->cart ) {
		return;
	}
	$main = isset( $_POST['add-to-cart'] ) ? absint( $_POST['add-to-cart'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	if ( $main && (int) $product_id !== $main ) {
		return;
	}
	$busy    = true;
	$allowed = array_map(
		function ( $g ) {
			return $g->get_id();
		},
		df_gift_products( $product_id )
	);
	foreach ( array_unique( array_map( 'absint', (array) wp_unslash( $_POST['df_gifts'] ) ) ) as $gid ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( in_array( $gid, $allowed, true ) && $gid !== (int) $product_id ) {
			WC()->cart->add_to_cart( $gid, 1, 0, array(), array( 'df_gift_for' => get_the_title( $product_id ) ) );
		}
	}
	$busy = false;
}
add_action( 'woocommerce_add_to_cart', 'df_gift_add_to_cart', 20, 2 );

/**
 * Sepette / siparişte "Hediye" etiketi.
 *
 * @param array $data Satır verisi.
 * @param array $item Sepet öğesi.
 * @return array
 */
function df_gift_item_data( $data, $item ) {
	if ( ! empty( $item['df_gift_for'] ) ) {
		$data[] = array(
			'key'   => 'Hediye',
			'value' => $item['df_gift_for'] . ' ile birlikte',
		);
	}
	return $data;
}
add_filter( 'woocommerce_get_item_data', 'df_gift_item_data', 10, 2 );

/**
 * Sipariş satırına hediye bilgisini yaz.
 *
 * @param WC_Order_Item_Product $item   Satır.
 * @param string                $key    Anahtar.
 * @param array                 $values Değerler.
 */
function df_gift_order_item( $item, $key, $values ) {
	if ( ! empty( $values['df_gift_for'] ) ) {
		$item->add_meta_data( 'Hediye', $values['df_gift_for'] . ' ile birlikte' );
	}
}
add_action( 'woocommerce_checkout_create_order_line_item', 'df_gift_order_item', 10, 3 );

/**
 * Hediye ürünlerini liste sorgularından çıkar.
 *
 * @param array $q wc_get_products argümanları.
 * @return array
 */
function df_gift_exclude_query( $q ) {
	if ( is_admin() || ! df_gift_ids_all() ) {
		return $q;
	}
	$q['exclude'] = array_merge( isset( $q['exclude'] ) ? (array) $q['exclude'] : array(), df_gift_ids_all() );
	return $q;
}
add_filter( 'df_query_products_args', 'df_gift_exclude_query' );

/* -------------------------------------------------------------------------
 * Yapay zekâ ile kart notu
 * ---------------------------------------------------------------------- */

/**
 * Tonlar.
 *
 * @return array<string,string>
 */
function df_ai_tones() {
	return array(
		'samimi'   => 'Samimi & sıcak',
		'romantik' => 'Romantik',
		'duygusal' => 'Duygusal',
		'esprili'  => 'Esprili',
		'resmi'    => 'Resmi / kurumsal',
		'kisa'     => 'Kısa & öz',
	);
}

/**
 * Öneri kutusu (çiçek notu adımında).
 */
function df_ai_box() {
	if ( ! df_opt( 'ai_on', 1 ) ) {
		return;
	}
	?>
	<div class="df-ai" data-df-ai>
		<div class="df-ai__head"><?php df_the_icon( 'sparkle', array( 'size' => 18 ) ); ?><strong>Yapay zekâ ile kart notu</strong><span>Kime, ne için gönderdiğinizi birkaç kelimeyle yazın; size özel 4 not önerelim.</span></div>
		<div class="df-ai__row">
			<select class="df-ai__tone" aria-label="Notun tonu">
				<?php foreach ( df_ai_tones() as $k => $l ) : ?>
					<option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $l ); ?></option>
				<?php endforeach; ?>
			</select>
			<input type="text" class="df-ai__hint" maxlength="160" placeholder="Ör. eşime 10. yıl dönümümüz, Alsancak'ta tanıştık" aria-label="Not için ipucu">
			<button type="button" class="df-ai__go" data-df-ai-go><?php df_the_icon( 'sparkle', array( 'size' => 16 ) ); ?><span>Not öner</span></button>
		</div>
		<div class="df-ai__out" data-df-ai-out aria-live="polite"></div>
	</div>
	<?php
}

/**
 * Türkçe küçük harf.
 *
 * @param string $s Metin.
 * @return string
 */
function df_ai_lower( $s ) {
	return mb_strtolower( strtr( (string) $s, array( 'I' => 'ı', 'İ' => 'i' ) ), 'UTF-8' );
}

/**
 * Hazır mesajlardan kişiselleştirilmiş öneri (API anahtarı yoksa ya da hata olursa).
 *
 * @param string $cat  Kategori.
 * @param string $tone Ton.
 * @param string $to   Alıcı adı.
 * @param string $hint İpucu.
 * @return string[]
 */
function df_ai_local( $cat, $tone, $to, $hint ) {
	$all  = df_note_templates();
	$pool = isset( $all[ $cat ] ) ? $all[ $cat ] : array();
	if ( ! $pool ) {
		// Kategori seçilmediyse ipucundan tahmin et; karışık (alakasız) notlar gösterme.
		$h   = df_ai_lower( $hint . ' ' . $cat );
		$map = array(
			'Doğum Günü'       => array( 'doğum', 'yaş günü', 'yaşına' ),
			'Yıl Dönümü'       => array( 'yıl dönüm', 'yıldönüm', 'evlilik' ),
			'Sevgililer Günü'  => array( 'sevgili', 'aşk', 'seviyorum', 'eşime', 'karıma', 'kocama' ),
			'Anneler Günü'     => array( 'anne' ),
			'Geçmiş Olsun'     => array( 'geçmiş olsun', 'hastane', 'ameliyat', 'şifa' ),
			'Teşekkür'         => array( 'teşekkür', 'sağ ol' ),
			'Özür'             => array( 'özür', 'affet', 'kırdım' ),
			'Tebrik & Yeni İş' => array( 'tebrik', 'yeni iş', 'terfi', 'mezun', 'açılış' ),
			'Söz & Nişan'      => array( 'söz', 'nişan', 'isteme' ),
			'Yeni Doğan'       => array( 'bebek', 'doğum yaptı', 'yeni doğan' ),
			'Öğretmenler Günü' => array( 'öğretmen' ),
		);
		foreach ( $map as $c => $words ) {
			foreach ( $words as $w ) {
				if ( isset( $all[ $c ] ) && false !== mb_strpos( $h, $w ) ) {
					$pool = $all[ $c ];
					break 2;
				}
			}
		}
	}
	if ( ! $pool ) {
		foreach ( array( 'Teşekkür', 'Tebrik & Yeni İş', 'Doğum Günü' ) as $c ) {
			$pool = array_merge( $pool, isset( $all[ $c ] ) ? array_slice( $all[ $c ], 0, 2 ) : array() );
		}
	}
	shuffle( $pool );
	$first = trim( strtok( (string) $to, ' ' ) );
	$out   = array();
	foreach ( array_slice( $pool, 0, 4 ) as $msg ) {
		$txt = $first && 'resmi' !== $tone ? $first . ', ' . mb_strtolower( strtr( mb_substr( $msg, 0, 1 ), array( 'İ' => 'i', 'I' => 'ı' ) ) ) . mb_substr( $msg, 1 ) : $msg;
		if ( 'kisa' === $tone ) {
			$txt = preg_replace( '/([.!?]).*$/us', '$1', $txt );
		}
		$out[] = $txt;
	}
	return $out;
}

/**
 * Kart notu için kullanılacak yapay zekâ sağlayıcısı: Ürün Asistanı'nda seçilen (Gemini / ChatGPT / Claude),
 * anahtarı yoksa Claude anahtarı; hiçbiri yoksa boş (hazır mesajlar).
 *
 * @return string
 */
function df_ai_note_provider() {
	$prov = (string) df_opt( 'pai_provider', 'openai' );
	if ( function_exists( 'df_pai_key' ) && '' !== df_pai_key( $prov ) ) {
		return $prov;
	}
	return '' !== trim( (string) df_opt( 'ai_key' ) ) ? 'claude' : '';
}

/**
 * Kart notu talimatı.
 *
 * @param array $in cat, tone, to, from, hint, product.
 * @return string
 */
function df_ai_note_prompt( $in ) {
	$max   = min( absint( df_opt( 'note_max', 300 ) ), 240 );
	$tones = df_ai_tones();
	$tone  = isset( $tones[ $in['tone'] ] ) ? $tones[ $in['tone'] ] : 'Samimi & sıcak';
	return "Bir çiçekçide, çiçekle birlikte gönderilecek küçük kartın notunu yazıyorsun. Türkçe, 4 farklı not öner.\n\n"
		. 'Durum / özel gün: ' . ( '' !== $in['cat'] ? $in['cat'] : 'belirtilmedi (genel)' ) . "\n"
		. 'Ton: ' . $tone . "\n"
		. ( '' !== $in['to'] ? 'Alıcının adı: ' . $in['to'] . " (uygunsa yalnızca ilk adını kullan)\n" : '' )
		. ( '' !== $in['hint'] ? 'Gönderenin anlattığı (notun asıl konusu bu olsun): ' . $in['hint'] . "\n" : '' )
		. ( '' !== $in['product'] ? 'Gönderilen çiçek: ' . $in['product'] . " (çiçeğin adını nota yazma)\n" : '' )
		. "\nKurallar:\n"
		. '- Her not en fazla ' . $max . " karakter; kart küçük, kısa ve etkili olsun.\n"
		. "- 4 not birbirinden gerçekten farklı olsun: biri kısa ve vurucu, biri duygusal, biri ipucundaki ayrıntıya dokunan, biri tona en uygun.\n"
		. "- Doğal, içten, günlük Türkçe; klişe ve abartı yok; emoji, hashtag, tırnak işareti yok.\n"
		. "- İmza ekleme (imza kartta ayrıca basılır). Uydurma bilgi ekleme.\n"
		. "- Resmi tonda 'siz' dili, diğerlerinde 'sen' dili kullan.\n"
		. 'Yanıtı yalnızca JSON olarak ver: {"notes": ["...", "...", "...", "..."]}';
}

/**
 * Yapay zekâ ile kart notu önerileri.
 *
 * @param array $in Girdiler.
 * @return string[]|WP_Error
 */
function df_ai_notes_remote( $in ) {
	$prov = df_ai_note_provider();
	if ( '' === $prov || ! function_exists( 'df_pai_call' ) ) {
		return new WP_Error( 'df_ai', 'Yapay zekâ anahtarı girilmemiş.' );
	}
	$text = df_pai_call( $prov, df_ai_note_prompt( $in ) );
	if ( is_wp_error( $text ) ) {
		return $text;
	}
	if ( ! preg_match( '/\{.*\}/s', (string) $text, $m ) ) {
		return new WP_Error( 'df_ai', 'Yanıt okunamadı.' );
	}
	$json  = json_decode( $m[0], true );
	$max   = absint( df_opt( 'note_max', 300 ) );
	$notes = array();
	foreach ( isset( $json['notes'] ) ? (array) $json['notes'] : array() as $n ) {
		$n = trim( sanitize_textarea_field( (string) $n ), " \t\n\"'“”" );
		if ( '' !== $n ) {
			$notes[] = mb_substr( $n, 0, $max );
		}
	}
	return $notes ? array_slice( $notes, 0, 4 ) : new WP_Error( 'df_ai', 'Boş yanıt.' );
}

/**
 * AJAX: kart notu önerisi.
 */
function df_ai_ajax() {
	check_ajax_referer( 'df_ai', 'nonce' );
	if ( ! df_opt( 'ai_on', 1 ) ) {
		wp_send_json_error();
	}
	$ip    = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$tkey  = 'df_ai_' . md5( $ip );
	$count = (int) get_transient( $tkey );
	if ( $count >= absint( df_opt( 'ai_limit', 15 ) ) && ! current_user_can( 'edit_shop_orders' ) ) {
		wp_send_json_error( array( 'message' => 'Çok fazla öneri istendi, lütfen biraz sonra tekrar deneyin.' ) );
	}
	set_transient( $tkey, $count + 1, HOUR_IN_SECONDS );
	$g  = function ( $k, $len = 160 ) {
		return isset( $_POST[ $k ] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST[ $k ] ) ), 0, $len ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- yukarıda doğrulandı.
	};
	$in = array(
		'tone'    => array_key_exists( $g( 'tone' ), df_ai_tones() ) ? $g( 'tone' ) : 'samimi',
		'cat'     => $g( 'cat', 60 ),
		'to'      => $g( 'to', 60 ),
		'from'    => $g( 'from', 60 ),
		'hint'    => $g( 'hint' ),
		'product' => $g( 'product', 120 ),
	);
	$notes = df_ai_notes_remote( $in );
	$debug = '';
	if ( is_wp_error( $notes ) ) {
		$debug = $notes->get_error_message();
		$notes = df_ai_local( $in['cat'], $in['tone'], $in['to'], $in['hint'] );
	}
	$out = array( 'notes' => array_values( $notes ) );
	if ( $debug && current_user_can( 'edit_shop_orders' ) ) {
		$out['admin'] = 'Yönetici notu: yapay zekâdan öneri alınamadı (' . $debug . '), hazır mesajlar gösteriliyor. Bu not yalnızca size görünür.';
	}
	wp_send_json_success( $out );
}
add_action( 'wp_ajax_df_ai_note', 'df_ai_ajax' );
add_action( 'wp_ajax_nopriv_df_ai_note', 'df_ai_ajax' );
