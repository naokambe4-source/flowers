# Kurulum Rehberi (cPanel)

## Gereksinimler
- PHP **8.3** veya üzeri (cPanel → *Select PHP Version* / *MultiPHP Manager*)
- Zorunlu PHP uzantıları: `pdo_mysql`, `mbstring`, `fileinfo`, `dom`, `xml`, `openssl` (`sodium` önerilir ama zorunlu değildir; yoksa gizli değerler OpenSSL AES-256-GCM ile şifrelenir)
- Önerilen: `curl` (API sağlayıcıları), `gd` (görsel boyutlandırma ve QR PNG), `zip` (XLSX), `exif`
- MySQL 8+ veya MariaDB 10.6+
- Apache veya LiteSpeed, `.htaccess` (AllowOverride) açık
- SSL sertifikası (AutoSSL / Let’s Encrypt) — canlı kullanımda zorunlu

## Adımlar
1. **Veritabanı:** cPanel → *MySQL Databases* → yeni veritabanı ve kullanıcı oluşturun, kullanıcıya veritabanında *ALL PRIVILEGES* verin. Veritabanı **boş** olmalıdır.
2. **Dosyalar:** `kurumsal-konaklama-x.y.z.zip` dosyasını *File Manager* ile kurulum klasörüne yükleyip açın:
   - Ana domain: `public_html/`
   - Alt klasör: `public_html/oteller/`
   - İç içe klasör: `public_html/kurumsal/konaklama/`
   Arşivdeki **gizli `.htaccess` dosyalarının** da açıldığından emin olun (File Manager → *Settings → Show Hidden Files*).
3. **İzinler:** klasörler 755, dosyalar 644. `config/` ve `storage/` (alt klasörleriyle) PHP tarafından yazılabilir olmalı.
4. **Sihirbaz:** tarayıcıda kurulum adresini açın (ör. `https://alanadi.com/oteller/`). Sistem otomatik olarak `…/index.php/kurulum` sihirbazına yönlenir.
   - Ortam kontrolleri: PHP, uzantılar, yazma izinleri, HTTPS, **temiz adres (rewrite) testi**, algılanan kurulum yolu.
   - Rewrite çalışmıyorsa kurulum **tamamlanmaz** ve tanı mesajı gösterilir (sayfaların sonradan 404 vermesini önlemek için).
   - Veritabanı bilgileri, site adresi, site adı ve ilk **Super Admin** hesabını girin.
   - **Üyelik kaydı** modunu seçin (erişim talebi / açık kayıt / kapalı) — sonradan değiştirilebilir.
   - Sistemi önce denemek istiyorsanız **“Demo otelleri yükle”** kutusunu işaretleyin (aşağıya bakın).
5. Kurulum tamamlanınca `config/config.php` oluşturulur (uygulama şifreleme anahtarı ve cron anahtarı dahil), migration’lar çalışır ve `storage/installed.lock` ile sihirbaz kilitlenir.
6. **Cron:** `docs/CRON-VE-EPOSTA.md` adımlarını uygulayın.
7. Yönetim paneli → **Dashboard**’daki “Yayın öncesi tamamlanması gerekenler” listesini bitirin: destek telefonu/WhatsApp, KVKK / gizlilik / kullanım koşulları metinleri, SMTP.

## İlk içerik kurulumu (önerilen sıra)
1. İçerik Yönetimi → logo, site adı, giriş ve ana sayfa görselleri, iletişim bilgileri, yasal metinler
2. Kurum Tipleri / Fiyat Grupları → Kurumlar (kuruma özel indirim gerekiyorsa)
3. Sistem Ayarları → varsayılan üye indirimi (%10), azami indirim, KDV/konaklama vergisi, SMTP
4. Oteller → *Yeni otel ekle* sihirbazı (7 adım) → odalar → fotoğraflar
5. Fiyatlar → fiyat planı + toplu gecelik fiyat; Kontenjan → oda adetleri
6. Üyeler → tek tek ekleyin veya CSV/XLSX aktarın; ya da Başvurular’dan onaylayın

## Demo modu ve canlıya geçiş
Sistemi gerçek otelleri girmeden denemek için **Yönetim → Demo / Canlı Mod → Demo verileri yükle** (veya kurulumdaki kutu, veya `php bin/demo.php yukle`).
- 14 kurgusal otel (Lara, Kundu, Belek, Kadriye, Side, Manavgat, Alanya, Kemer, Beldibi, Tekirova, Kaleiçi, şehir merkezi, Kaş, Kalkan), 32 oda tipi, 12 aylık sezonluk fiyat ve kontenjan, örnek erken rezervasyon kuralı, otel/oda/karşılama ekranları için **temsili** görseller yüklenir.
- Anında onaylı oteller kesin fiyat; Belek ve Tekirova örnekleri “onaya bağlı hedef teklif” akışını gösterir.
- Demo açıkken üye ve yönetim ekranlarının üstünde **DEMO MODU** şeridi görünür; demo görselleri “Temsili görsel” etiketiyle gösterilir.
- **Canlıya geçiş:** Demo / Canlı Mod sayfasında kutuya `CANLI` yazıp *Canlı moda geç* (veya `php bin/demo.php kaldir`). Yalnız demo kayıtları silinir: demo oteller, odaları, fiyatları, kontenjanları, görselleri, demo kuralı ve demo otellere yapılmış deneme rezervasyon/teklifleri. Sizin girdiğiniz oteller, kurumlar, üyeler ve ayarlar korunur.

## Gerçek otellerle canlı kullanım (demo yerine)
**Yönetim → Canlı Otel Verisi**:
1. (Varsa) Demo / Canlı Mod sayfasından demo verileri kaldırın.
2. **OpenStreetMap** — anahtar gerekmez. Kaynak: OpenStreetMap, bölgeleri işaretleyin → *İçe aktar*. Gerçek oteller (ad, yıldız, konum, telefon, web) eklenir; fiyat yoktur, üyeler teklif ister.
3. **LiteAPI** — https://dashboard.liteapi.travel adresinden ücretsiz hesap açın, API anahtarını yapıştırıp *Kaydet ve bağlan* deyin (bağlantı test edilir, canlı fiyat açılır). Ardından Kaynak: LiteAPI ile bölgeleri içe aktarın: fotoğraflar, açıklamalar ve olanaklar gelir; otel sayfasında canlı oda fiyatları ve anında rezervasyon çalışır. Aynı otel OpenStreetMap’ten de geldiyse kayıtlar birleşir.
4. Paylaşımlı hostingte bir istek ~20 sn’de durur; kalan bölgeler için işlemi tekrar başlatın (eklenen oteller tekrar eklenmez). SSH varsa: `php bin/import-hotels.php osm all`, `php bin/import-hotels.php liteapi all`.
5. Sunucunun dışarıya HTTPS bağlantısı (cURL) açık olmalıdır: `overpass-api.de`, `api.liteapi.travel`, `book.liteapi.travel` ve LiteAPI görsel adresleri.

## Üyelik kaydı modu
**Yönetim → Sistem Ayarları → Üyelik** bölümünden seçilir:
| Mod | Davranış |
|---|---|
| Erişim talebi (varsayılan) | Giriş ekranında “Erişim talebi oluştur”; başvuru yönetici/kurum yöneticisi onayıyla hesaba dönüşür. |
| Açık kayıt | Giriş ekranında “Hesap oluştur”; kullanıcı parolasını belirleyip **hemen** Standart Üye olarak giriş yapar. İsteğe bağlı: izinli e-posta alan adları (örn. `antalya.gov.tr`; alt alan adları da kabul edilir) ve kurum seçimini zorunlu kılma. |
| Kapalı | Kendi kendine kayıt ve başvuru kapalıdır; hesapları yalnız yönetim veya CSV/XLSX aktarımı açar. |

> Demo seçilmezse kurulum **örnek otel, sahte fiyat, test kullanıcısı veya demo içeriği oluşturmaz.** Yalnız roller/izinler, Antalya bölgeleri, konseptler, özellikler, kurum tipleri, bildirim şablonları, boş yasal sayfa kayıtları ve varsayılan ayarlar yüklenir. Harici API sağlayıcıları kapalı gelir.

## Elle kurulum (sihirbaz kullanılamıyorsa)
1. `config/config.example.php` → `config/config.php` olarak kopyalayıp değerleri doldurun (`key` için: `php -r "echo 'base64:'.base64_encode(random_bytes(32));"`).
2. `php bin/migrate.php`
3. `php bin/create-admin.php eposta@kurum.gov.tr Ad Soyad`
4. `storage/installed.lock` dosyasını oluşturun.

## Sorun giderme
| Belirti | Çözüm |
|---|---|
| Sihirbazda “Temiz adresler çalışmıyor” | `.htaccess` yüklenmemiş veya AllowOverride kapalı. Hosting desteğinden `AllowOverride All` isteyin; LiteSpeed’de .htaccess desteği açık olmalı. |
| Beyaz sayfa / 500 | `storage/logs/app-YYYY-MM-DD.log` dosyasına bakın; PHP sürümünün 8.3 olduğunu doğrulayın. |
| Görseller yüklenmiyor | `storage/private` yazılabilir mi; `upload_max_filesize` ≥ 8M olmalı. |
| PDF voucher Türkçe karakter | dompdf DejaVu fontları paketle gelir; `storage/tmp` yazılabilir olmalı. |
